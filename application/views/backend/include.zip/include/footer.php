
		</div>
		<!-- jQuery -->
		<script src="<?php echo base_url('');?>assets1/vendor/jquery.min.js"></script>
		<script src="<?php echo base_url('');?>assets1/vendor/bootstrap.min.js"></script>
		<!-- Perfect Scrollbar -->
		<script src="<?php echo base_url('');?>assets1/vendor/perfect-scrollbar.min.js"></script>
		<!-- MDK -->
		<script src="<?php echo base_url('');?>assets1/vendor/dom-factory.js"></script>
		<script src="<?php echo base_url('');?>assets1/vendor/material-design-kit.js"></script>
		<!-- App JS -->
		<script src="<?php echo base_url('');?>assets1/js/app.js"></script>
	</body>
</html>