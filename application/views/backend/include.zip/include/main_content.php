<!-- Header Layout Content -->

<div class="mdk-header-layout__content">
	<div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
		<div class="mdk-drawer-layout__content page ">
			<div class="container-fluid page__container">
				<br>
				<?php if($this->session->flashdata('flashSuccess')) { ?>
				    <div style="width: 30%;margin-top: -4%;z-index: 1;margin-left: 35%;" class="alert alert-dismissible bg-success text-white border-0 fade show successmsg" role="alert">
				        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				            <span aria-hidden="true">&times;</span>
				        </button>
				        <?php echo $this->session->flashdata("flashSuccess"); ?>
				    </div>
				<?php } ?> 
				<?php if($this->session->flashdata('flashError')) { ?>
				    <div style="width: 30%;margin-top: -4%;z-index: 1;margin-left: 35%;" class="alert alert-dismissible bg-danger text-white border-0 fade show errormsg" role="alert">
				        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				            <span aria-hidden="true">&times;</span>
				        </button>
				        <?php echo $this->session->flashdata("flashError"); ?>
				    </div>
				<?php } ?>
				<!-- <ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="<?php echo base_url('Admin/dashboard/')?>">Home</a></li>
					<li class="breadcrumb-item active">Dashboard</li>
				</ol> -->
				<h1 class="h2">Dashboard</h1>
				
            	<ul class="nav nav-tabs">
                    <li class="nav-item">
                        <a class="nav-link active" href="#first" data-toggle="tab">My Shops</a>
                    </li>
                    &nbsp;
                    <li class="nav-item">
                        <a class="nav-link" href="#second" data-toggle="tab">Payment Gateway</a>
                    </li>
                    &nbsp;
                    <li class="nav-item">
                        <a class="nav-link" href="#third" data-toggle="tab">Reports</a>
                    </li>
                    &nbsp;
                    <li class="nav-item">
                        <a class="nav-link" href="#fourth" data-toggle="tab">Communication</a>
                    </li>
                </ul>
                <!-- <br> -->
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="tab-content card-body">
                        	    <div class="tab-pane active" id="first">
                        	        <div class="row">
                                        <div class="col-sm-4">
                                            <a href="<?php echo base_url('backend/MyShopController/addShop');?>" style="text-decoration: none">
                                                <div class="panel panel-default first-panel" >
                                                    <div class="panel-body" >
                                                    	<span class="text">New store</span>
                                                    	<br>
                                                    	<img src="<?php echo base_url('assets/img/add-sign.png');?>" class="plus-icon" />
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                        <?php if(!empty($shopDetails)){ foreach ($shopDetails as $sd) { ?>
        	                                <div class="col-sm-4">
        	                                	<?php if($sd->shop_payment_status==0) {?>
            	                                	<a href="<?php echo base_url('backend/PaymentController/activateShop/'.$sd->shop_id);?>">
            		                                	<div class="panel panel-default second-panel">
            		                                	    <div class="row">
            		                                	        <div class="col-md-6">
            		                                	            <p class="second-text"><?php echo $sd->shop_name;?> </p>
            		                                	        </div>
            		                                	        <div class="col-md-6">
            		                                	            <img src="<?php echo base_url('assets1/img/logo.png')?>" class="boximage"/>
            		                                	        </div>
            		                                	    </div>
            		                                	 </div>
            	                                    </a>
        	                                    <?php } else {?>
            	                                    <a href="<?php echo base_url('backend/MyShopController/myShop/'.$sd->shopId. '/' .$sd->shop_db_name);?>">
            	                                    	<div class="panel panel-default second-panel">
            		                                		<div class="row">
            		                                	        <div class="col-md-6">
            		                                	            <p class="second-text"><?php echo $sd->shop_name;?> </p>
            		                                	        </div>
            		                                	        <div class="col-md-6">
            		                                	            <img src="<?php echo base_url('assets1/img/logo.png')?>" class="boximage"/>
            		                                	        </div>
            		                                	    </div>
            	                                    	</div>
        	                                    	</a>
        	                                    <?php }?>
                                            </div>
                                        <?php } }?>
                                    </div>
                        	    </div>
                        	    <div class="tab-pane" id="second">
                        	        <div class="row">
                                        <div class="col-sm-4">
                                            <a href="<?php echo base_url('backend/PaymentController/addPaymentMethod');?>" style="text-decoration: none">
                                                <div class="panel panel-default first-panel" >
                                                    <div class="panel-body" >
                                                    	<span class="text" align="center">Add Payment</span>
                                                    	<br>
                                                    	<img src="<?php echo base_url('assets1/img/add-sign.png');?>" class="plus-icon" />
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                        <?php if(!empty($paymentDetails)){ foreach ($paymentDetails as $sd) { ?>
        	                                <div class="col-sm-4">
        	                                    <a href="<?php echo base_url('backend/PaymentController/viewPaymentDocumentation/'.$sd->payment_id);?>">
            	                                	<div class="panel panel-default second-panel">
            	                                		<p class="second-text"><?php echo $sd->payment_name;?></p>
                                                	</div>
                                            	</a>
                                            </div>
                                        <?php } }?>
                                    </div>
                        	    </div>
                        	    <div class="tab-pane" id="third">
                        	        <h1>Reports</h1>
                        	    </div>
                        	    <div class="tab-pane" id="fourth">
                        	        <h1>Communication</h1>
                        	    </div>
                        	</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h1>PalceHolder</h1>
                            </div>
                        </div>
                    </div>
                </div>
			</div>
			<!-- container-fluid -->
		</div>
		<!-- End Page-content -->
		<?php $this->load->view('backend/include/sidebar');?>
		<?php if($this->session->flashdata('flashSuccess')) { ?>
		    <script type="text/javascript">
		        window.setTimeout(function() {
		            $(".successmsg").fadeTo(1000, 0).slideUp(500, function(){
		                $(this).remove(); 
		            });
		        }, 3000);
		    </script>
		<?php } ?>  
		<?php if($this->session->flashdata('flashError')) { ?>
		    <script type="text/javascript">
		        window.setTimeout(function() {
		            $(".errormsg").fadeTo(900, 0).slideUp(800, function(){
		                $(this).remove(); 
		            });
		        }, 4000);
		    </script>
		<?php } ?> 
		<style type="text/css">
			.plus-icon {
        		width: 50px;
        		height: 50px;
        		/*margin-left: 80px;*/
          /*  	margin-top:15px;*/
    		}
        	.first-panel{
                height: 100%;
                border: 1px solid #dcdcdc;
                -webkit-transition: -webkit-box-shadow .2s linear;
                transition: -webkit-box-shadow .2s linear;
                transition: box-shadow .2s linear;
                transition: box-shadow .2s linear, -webkit-box-shadow .2s linear;
                padding: 16px;
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
                
            }
        	.text{
	        	color:#000;
	        	font-size:1rem;
	        	/*margin-left:75px;*/
	        }
	        
	        .second-panel{
                height: 100%;
                border: 1px solid #dcdcdc;
                -webkit-transition: -webkit-box-shadow .2s linear;
                transition: -webkit-box-shadow .2s linear;
                transition: box-shadow .2s linear;
                transition: box-shadow .2s linear, -webkit-box-shadow .2s linear;
                padding: 16px;
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
                
            }
            .second-text{
	        	color:#000;
	        	font-size:1rem;
	        	width:100px;
	        	/*margin-left:75px;*/
	        }
	        .panel:hover {
                -webkit-box-shadow: 4px 4px 15px -2px rgba(0, 0, 0, .19);
                box-shadow: 4px 4px 15px -2px rgba(0, 0, 0, .19)
            }
            .boximage{
                width:150px;
                height:100px;
                float:left;
                margin-left:-10px;
                margin-top: -30px;
                /*padding:10px;*/
                /*margin-right: 10px;*/
            }
            
		    /*@media (max-width:320px) {*/
		    /*    .first-panel{*/
		    /*    	background-color:#8CB2F6;*/
	     /*       	border-radius: 15px;*/
		    /*        border-style:solid;*/
		    /*        color:#8CB2F6;*/
		    /*        margin-bottom:1.5rem;*/
		    /*    	height:100px;*/
		    /*        width:170px;*/
		    /*    }*/
		    /*    .plus-icon {*/
	     /*       	margin-left: 50px;*/
	     /*       	margin-bottom: 5px;*/
	     /*   	}*/
		    /*}*/
		    /*@media (max-width: 280px){*/
		    /*    .first-panel{*/
		    /*    	background-color:#8CB2F6;*/
	     /*       	border-radius: 15px;*/
		    /*        border-style:solid;*/
		    /*        color:#8CB2F6;*/
		    /*        margin-bottom:1.5rem;*/
		    /*    	height:100px;*/
		    /*        width:170px;*/
		    /*    }*/
		    /*}*/

	     /*   .second-panel{*/
	     /*       background-color:#FFBF00;*/
	     /*       border-color:#FFBF00;*/
	     /*       border-radius: 15px;*/
	     /*       border-width:2px;*/
	     /*       border-style:solid;*/
	     /*       color:#8CB2F6;*/
	     /*       margin-bottom:1.5rem;*/
	     /*       width:250px;*/
	     /*       height:120px;*/
	     /*   }*/

	     /*   .third-panel{*/
	     /*       background-color:#4BB543;*/
	     /*       border-color:#4BB543;*/
	     /*       border-radius: 15px;*/
	     /*       border-width:2px;*/
	     /*       border-style:solid;*/
	     /*       color:#8CB2F6;*/
	     /*       margin-bottom:1.5rem;*/
	     /*       width:250px;*/
	     /*       height:120px;*/
	     /*   }*/

	     /*   .fourth-panel{*/
	     /*       background-color:#8CB2F6;*/
	     /*       border-color:#8CB2F6;*/
	     /*       border-radius: 15px;*/
	     /*       border-width:2px;*/
	     /*       border-style:solid;*/
	     /*       color:#8CB2F6;*/
	     /*       margin-bottom:1.5rem;*/
	     /*       width:250px;*/
	     /*       height:120px;*/
	     /*   }*/

	     /*   .second-text{*/
	     /*   	color:#000;*/
	     /*   	font-size:1rem;*/
	     /*   	text-align: center;*/
	     /*   }*/

	     /*   #shopbutton{*/
	     /*   	background-color: #4C80E1;*/
	     /*   	border-color:#4C80E1;*/
	     /*   	margin-top:20px;*/
	     /*   	color:#fff;*/
	     /*   }*/

	     /*   #warningbtn{*/
	     /*   	background-color: #DF7613;*/
	     /*   	border-color:#DF7613;*/
	     /*   	margin-top:20px;*/
	     /*   	color:#fff;*/
	     /*   }*/

	     /*   #successbtn{*/
	     /*   	background-color: #229C1A;*/
	     /*   	border-color:#229C1A;*/
	     /*   	margin-top:20px;*/
	     /*   	color:#fff;*/
	     /*   }*/

		    /*@media (max-width:320px) {*/
		    /*    .second-panel{*/
		    /*    	background-color:#8CB2F6;*/
		    /*        border-radius: 15px;*/
		    /*        border-width:2px;*/
		    /*        border-style:solid;*/
		    /*        color:#8CB2F6;*/
		    /*        margin-bottom:1.5rem;*/
		    /*        width:250px;*/
		    /*        height:120px;*/
		    /*    }*/
		    /*    .text{*/
		    /*    	color:#000;*/
		    /*    	font-size:1rem;*/
		    /*    	margin-left:45px;*/
		    /*    }*/
		    /*}*/
		    /*@media (max-width: 280px){*/
		    /*    .second-panel{*/
		    /*    	background-color:#8CB2F6;*/
		    /*        border-radius: 15px;*/
		    /*        border-width:2px;*/
		    /*        border-style:solid;*/
		    /*        color:#8CB2F6;*/
		    /*        margin-bottom:1.5rem;*/
		    /*        width:250px;*/
		    /*        height:120px;*/
		    /*    }*/
		    /*    .text{*/
		    /*    	color:#000;*/
		    /*    	font-size:1rem;*/
		    /*    	margin-left:45px;*/
		    /*    }*/
		    /*}*/
		</style>