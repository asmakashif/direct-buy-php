<?php $this->load->view('backend/include/header'); ?>
<?php $this->load->view($main_content); ?>
<?php $this->load->view('backend/include/footer'); ?>