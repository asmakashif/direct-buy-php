
<div class="mdk-header-layout__content">
	<div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
		<div class="mdk-drawer-layout__content page ">
			<div class="container-fluid page__container">
				<?php if($this->session->flashdata('flashSuccess')) { ?>
					<div style="width: 30%;margin-top: -4%;z-index: 1;margin-left: 35%;" class="alert alert-dismissible bg-success text-white border-0 fade show successmsg" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
						<?php echo $this->session->flashdata("flashSuccess"); ?>
					</div>
				<?php } ?> 
				<?php if($this->session->flashdata('flashError')) { ?>
					<div style="width: 30%;margin-top: -4%;z-index: 1;margin-left: 35%;" class="alert alert-dismissible bg-danger text-white border-0 fade show errormsg" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
						<?php echo $this->session->flashdata("flashError"); ?>
					</div>
				<?php } ?>
				<br>
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="<?php echo base_url('backend/MyShopController/index')?>">Home</a></li>
					<li class="breadcrumb-item active">Edit Shops</li>
				</ol>
				<h1 class="h2">Edit Shop</h1>
				<ul class="nav nav-tabs">
					<li class="nav-item">
						<a class="nav-link active" href="#first" data-toggle="tab">Store Information</a>
					</li>
					&nbsp;
					<li class="nav-item" id="tab2">
						<a class="nav-link" href="#store_config" data-toggle="tab">Store Configuration</a>
					</li>
					&nbsp;
					<?php if($shopSummary->upload_status=='Uploaded from base DB') { ?>
						<li class="nav-item">
							<a class="nav-link" href="<?php echo base_url('backend/MyShopController/editStrProductConfig/'.$shopId.'/'.'datafrombaseDB');?>">Product Configuration</a>
							
						</li>
					<?php } else {?>
						<li class="nav-item" id="tab3">
							<a class="nav-link" style="cursor: pointer">Product Configuration</a>
						</li>
					<?php }?>
					<li class="nav-item" id="tab3">
						<a class="nav-link" href="#third" data-toggle="tab">View Products</a>
					</li>
					&nbsp;
					<li class="nav-item" id="tab4">
						<a class="nav-link" href="#fourth" data-toggle="tab">Store Summary</a>
					</li>
				</ul>

				<div class="">
					<div class="tab-content ">
						<div class="tab-pane active" id="first">
							<br>
							<div class="row">
								<div class="col-sm-12">
									<div class="card">
										<div class="card-body">
											<!-- <form  method="post" id="signinForm" > -->
											<form action="<?php echo base_url('backend/MyShopController/updateShopDetails');?>" method="post">
												<div class="row">
													<div class="col-md-6">
														<label for="shop_name"><b>Shop Name</b><small>(Only letters & numbers)</small></label>
														<input type="text" class="form-control" name="shop_name" id="shop_name" value="<?php if(isset($shopData->shop_name)) { echo $shopData->shop_name; } ?>" title="Only letters (either case), numbers" placeholder="Enter Shop Name" pattern="[a-zA-Z0-9]+" required="">
                                                        <span id='message'></span>
														<input type="hidden" class="form-control" name="shopId" value="<?php if(isset($shopData->shopId)) { echo $shopData->shopId; } ?>">

														<input type="hidden" class="form-control" name="shop_db_name" id="shop_db_name" value="<?php if(isset($shopData->shop_db_name)) { echo $shopData->shop_db_name; } ?>">

													</div>
													<div class="col-md-6">
														<label for="shop_address"><b>Shop Address</b></label>
														<textarea class="form-control" name="shop_address" id="shop_address"><?php if(isset($shopData->shop_address)) { echo $shopData->shop_address; } ?></textarea> 
													</div>
												</div>
												<input type="hidden" calss="form-control" name="editStrInfo" value="editStrInfo">
												<br>
												<div class="row">
													<div class="col-md-12">
														<?php if(!empty($this->uri->segment(4))) {?>
															<tr><b>Selected Shop Type : </b></tr>
															<?php foreach($shopTypebyid as $row) {?>
																<tr><?php if(isset($row->shop_type_name)) { echo $row->shop_type_name; } ?></tr>	
															<?php }?>
														<?php } else {?>
														<?php }?>
														<br>
														<br>
														<div id="accordion">
															<div class="card">
																<div class="card-header" id="headingOne" style="background-color:#4C80E1">
																	<h5 class="mb-0">
																		<button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne" style="color:#fff;background-color:#32405A">
																			Select to change Shop Type
																		</button>
																	</h5>
																</div>
																<div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
																	<table class="table mb-0">
																		<thead>
																			<tr>
																				<th></th>
																				<th>Shop Type</th>
																				<th>Shop type Description</th>
																			</tr>
																		</thead>

																		<?php foreach($shopType as $row) {?>	
																			<tbody class="list" id="search">
																				<tr>
																					<!-- <input type="checkbox" id="<?=$row->shop_type_id?>" name="shop_type[]" value="<?php echo $row->shop_type_id ;?>" <?php if($row->shop_type_id == $row->shop_type_id){echo'checked';} ?>> -->
																					<td><input type="checkbox" id="<?=$row->shop_type_id?>" name="shop_type[]" value="<?php echo $row->shop_type_id ;?>" ></td>
																					<td>
																						<?php echo $row->shop_type_name;?>
																					</td> 
																					<td>
																						<?php echo $row->shop_type_description;?>
																					</td>
																				</tr>
																			</tbody>
																		<?php }?>
																	</table>
																</div>
															</div>
														</div>
													</div>
												</div>
												<br>
												<input type="submit" class="btn btn-success" value="Save" name="submit">
												</form>

											</div>
										</div>
									</div>
								</div>
							</div>

							<div class="tab-pane" id="store_config">
								<br>
								<div class="row">
									<div class="col-sm-12">
										<div class="card">
											<div class="card-body">
												<div class="form-group">
													<div class="radio">
														<div class="ez-radio pull-left">
															<label>
																<strong>1. &nbsp; <span>I am configuring a Pharmaceutical store </span></strong>
															</label>
														</div>
														<div class="ez-radio">
															<label>
																<input type="radio" name="pharma" id="yesPharma" value="Yes" onclick="javascript:PharmaCheck();">
																Yes
															</label>
															<label>
																<input type="radio" name="pharma" id="noPharma" value="No" onclick="javascript:PharmaCheck();">
																No
															</label>
														</div>
													</div>
												</div>
												<div id="ifYesPharma" style="display:none">
													<div class="row">
														<div class="col-sm-12">
															<div class="radio">
																<div class="ez-radio pull-left">
																	<label>
																		<strong>2. &nbsp; <span>Pharmaceutical products will/should not be displayed to customer. Customer will have to upload their prescription</span></strong>
																	</label>
																	<br>
																	<span style="color:red"><b>Note:Cash on Delivery will be activated as default payment method for Pharma products</b></span>
																	<br>
																	<br>
																	<!--<form action="<?php echo base_url('backend/MyShopController/updatePharmaStatus/'.$this->uri->segment(4));?>" method="post">-->
																	<!--	<input type="hidden" class="form-control" value="1" name="pharmaYes">-->
																	<!--	<input type="submit" class="btn btn-success" value="Continue" name="submit">-->
																	<!--</form>-->
																</div>
															</div>
														</div>
													</div>
													&nbsp;
												</div>
												<div id="ifNoPharma" style="display:none">
													<div class="form-group">
														<div class="radio">
															<div class="ez-radio pull-left">
																<label>
																	<strong>2. &nbsp; <span>Do you have inventory (SKU) information of the products in your store? </span></strong>
																</label>
															</div>
															<div class="ez-radio">
																<label>
																	<input type="radio" name="product_info" id="yes" value="Yes" onclick="javascript:SKUCheck();">
																	Yes
																</label>
																<label>
																	<input type="radio" name="product_info" id="maybe" value="Maybe" onclick="javascript:SKUCheck();">
																	Maybe
																</label>
																<label>
																	<input type="radio" name="product_info" id="no" value="No" onclick="javascript:SKUCheck();">
																	No
																</label>
															</div>
														</div>
													</div>
												</div>
												<div id="ifYes" style="display:none">
													<div class="row">
														<div class="col-sm-12">
															<div class="radio">
																<div class="ez-radio pull-left">
																	<label>
																		<strong>3. &nbsp; <span>Would you be comfortable in uploading your store products by yourself or would you want assistance from Direct-Buy team? </span></strong>
																	</label>
																</div>

																<div class="ez-radio pull-left">
																	<label>
																		<input type="radio" onclick="javascript:yesCheck();" name="yes" value="I am comfortable" id="comfortableCheck">
																		I am comfortable
																	</label>
																	<label>
																		<input type="radio" onclick="javascript:yesCheck();" name="yes" value="I need help" id="helpCheck">
																		I need help
																	</label>
																</div>
															</div>
														</div>
													</div>
													&nbsp;
												</div>

												<div id="ifComfortable" style="display:none">
													<div class="row">
														<div class="col-sm-12">
															<div class="radio">
																<div class="ez-radio pull-left">
																	<label>
																		<strong>4. &nbsp; <span>Click here to download the template to upload your products data to your store</span></strong>
																	</label>
																</div>
																<div class="col-md-6">
																	
																	<!--<form method="post" action="<?php echo base_url('backend/ExportExcelController/exportProductDataFromBaseDB/');?>">-->
																	<!--	<input type="submit" name="export" class="btn btn-success" value="Export" onclick="javascript:exportCheck();" id="export"/>-->
																	<!--</form>-->
																</div>
															</div>
														</div>
													</div>
													&nbsp;
												</div>
												<div id="ifExport" style="display:none">
													<div class="row">
														<div class="col-sm-12">
															<div class="radio">
																<div class="ez-radio pull-left">
																	<label>
																		<strong>5. &nbsp; <span>Fill out the data and upload the file</span></strong>
																	</label>
																</div>

																<form action="<?php echo base_url('backend/ImportExcelController/importProductDataToBaseDB/'.$this->uri->segment(4));?>" method="post" enctype="multipart/form-data">
																	<div class="row">
																		<div class="col-md-6">
																			<input type="file" class="form-control" name="uploadFile"/>

																			<input type="hidden" value="" id="fullyuploadedbycustomer" name="fullyuploadedbycustomer">
																		</div>
																		<!--<div class="col-md-2">-->
																		<!--	<input type="submit" name="submit" class="btn btn-success" value="Import"/>-->
																		<!--</div>-->
																	</div>
																</form>
															</div>
														</div>
													</div>
													&nbsp;
												</div>

												<div id="ifMaybe" style="display:none">
													<div class="row">
														<div class="col-sm-12">
															<div class="radio">
																<div class="ez-radio pull-left">
																	<label>
																		<strong>3. &nbsp; <span>Would you confirm you have some data, but not all data?</span></strong>
																	</label>
																</div>

																<div class="ez-radio pull-left">
																	<label>
																		<input type="radio" onclick="javascript:maybeCheck();" name="maybe" value="Yes" id="maybeYesCheck">
																		Yes
																	</label>
																	<label>
																		<input type="radio" onclick="javascript:maybeCheck();" name="maybe" value="No" id="maybeNoCheck">
																		No
																	</label>
																</div>
															</div>
														</div>
													</div>
													&nbsp;
												</div>
												<div id="ifMaybeYes" style="display:none">
													<div class="row">
														<div class="col-sm-12">
															<div class="radio">
																<div class="ez-radio pull-left">
																	<label>
																		<strong>4. &nbsp; <span>Click here to download the template to upload your products data to your store.</span></strong>
																	</label>
																</div>
																<!--<div class="col-md-6">-->
																<!--	<form method="post" action="<?php echo base_url('backend/ExportExcelController/exportProductDataFromBaseDB/');?>">-->
																<!--		<input type="submit" name="export" class="btn btn-success" value="Export" onclick="javascript:maybeexportCheck();" id="maybeexport"/>-->
																<!--	</form>-->
																<!--</div>-->
															</div>
														</div>
													</div>
													&nbsp;
												</div>
												<div id="ifMaybeExport" style="display:none">
													<div class="row">
														<div class="col-sm-12">
															<div class="radio">
																<div class="ez-radio pull-left">
																	<label>
																		<strong>5. &nbsp; <span>Fill out the data and upload the file partially</span></strong>
																	</label>
																</div>
																<form action="<?php echo base_url('backend/ImportExcelController/importProductDataToBaseDB/'.$this->uri->segment(4));?>" method="post" enctype="multipart/form-data">
																	<div class="row">
																		<div class="col-md-6">
																			<input type="file" class="form-control" name="uploadFile"/>
																			<input type="hidden" value="" id="partiallyuploadedbycustomer" name="partiallyuploadedbycustomer">
																		</div>
																		<div class="col-md-2">
																			<input type="submit" name="submit" class="btn btn-success" value="Import"/>
																		</div>
																	</div>
																</form>
																<span><b>Note: You can also reach out to dataupload@direct-buy.in for data that you do not have.</b></span>
															</div>
														</div>
													</div>
													&nbsp;
												</div>
												<div id="ifHelp" style="display:none">
													<form action="<?php echo base_url('backend/MyShopController/continueWithoutProductUpload/'.$this->uri->segment(4));?>" method="post" >
														<div class="row">
															<div class="col-sm-12">
																<div class="radio">
																	<div class="ez-radio pull-left">
																		<label>
																			<strong>4. &nbsp; <span>Please email your products database to dataupload@direct-buy.in</span></strong>
																		</label>
																	</div>
																</div>
															</div>
														</div>
														<!--<input type="submit" class="btn btn-success" value="Continue" name="submit">-->
													</form>
													&nbsp;
												</div>
												<div id="ifNo" style="display:none">
													<div class="row">
														<div class="col-sm-12">
															<div class="radio">
																<div class="ez-radio pull-left">
																	<label>
																		<span><strong>“Direct-buy will provide you with limited information of products that Direct-Buy holds in its central database. This database is every growing and we keep up updated with more products as they get added to our central database. You can reach out to dataupload@direct-buy.in for data upload.” &nbsp;</strong></span>
																	</label>
																</div>
															</div>
														</div>
														<!--<form action="<?php echo base_url('backend/MyShopController/continueWithoutProductUpload/'.$this->uri->segment(4));?>" method="post" >-->
														<!--	<input type="submit" class="btn btn-success" value="Continue" name="submit">-->
														<!--</form>-->
													</div>
													&nbsp;
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="tab-pane" id="third">
								<br>
								<div class="row">
									<div class="col-sm-12">
										<div class="card">
											<div class="card-body">
											    <div style="float:right;">
												    <?php if($shopSummary->upload_status=='Uploaded from base DB') { ?>
												        <div class="row">
															<div class="col-md-3">
																<form method="post" action="<?php echo base_url('backend/ExportExcelController/exportProductDataFromTemp/'.$shopId);?>">
																	<input type="submit" name="export" class="btn btn-success" value="Export"/>
																</form>
															</div>
															<div class="col-md-9">
																<form action="<?php echo base_url('backend/ImportExcelController/importUpdatedProductDataToTemp/'.$shopId.'/'.'datafrombaseDB');?>" method="post" enctype="multipart/form-data">
																	<div class="row">
																		<div class="col-md-7">
																			<input type="file" class="form-control" name="uploadFile"/>
																		</div>
																		<div class="col-md-1">
																			<input type="submit" name="submit" class="btn btn-success" value="Import"/>
																		</div>
																	</div>
																</form>
															</div>
														</div>
													
													<?php } else {?>
													<?php }?>
												</div>
												<div class="table-responsive border-bottom" data-toggle="lists" data-lists-values='["js-lists-values-employee-name"]'>
													<br>
													<br>
													<?php if($this->uri->segment(5)=='notuploadedbycustomer') {?>
														<h2>No products uploaded</h2>
													<?php } else {?>
														<?php if(empty($shopProducts)) { ?>
															<div class="NofixTableHead">
																<table class="table" >
																	<thead>
																		<tr>
																			<th>Category</th>
																			<th>SubCategory</th>
																			<th>Brand</th>
																			<th>Product_Name</th>
																			<th>Product_Type</th>
																			<th>Product_SubType </th>
																			<th>Product_Description</th>
																			<th>Product_Weight</th>
																			<th>Product_Qty</th>
																			<th>Product_Price</th>
																			<th>Offer_Price</th>
																			<th>Product_Image</th>
																			<th>Product_Added_Date</th>
																		</tr>
																	</thead>
																	<tbody>
																		<tr>
																			<td colspan="6">Products(s) not found...</td>
																		</tr>
																	</tbody>
																</table>
															</div>
														<?php } else{ ?>
															<div class="fixTableHead">
																<table class="table" >
																	<thead>
																		<tr>
																			<th>Category</th>
																			<th>SubCategory</th>
																			<th>Brand</th>
																			<th>Product_Name</th>
																			<th>Product_Type</th>
																			<th>Product_SubType </th>
																			<th>Product_Description</th>
																			<th>Product_Weight</th>
																			<th>Product_Qty</th>
																			<th>Product_Price</th>
																			<th>Offer_Price</th>
																			<th>Product_Image</th>
																			<th>Product_Added_Date</th>
																		</tr>
																	</thead>
																	<?php $i=1; foreach ($shopProducts as $key => $row) { ?>
																		<tbody>
																			<tr>
																				<td>
																					<span class="js-lists-values-employee-name"><?php echo $row->category;?></span>
																				</td>
																				<td>
																					<span class="js-lists-values-employee-name"><?php echo $row->sub_category;?></span>
																				</td>
																				<td>
																					<span class="js-lists-values-employee-name"><?php echo $row->brand;?></span>
																				</td>
																				<td>
																					<span class="js-lists-values-employee-name"><?php echo $row->product_name;?></span>
																				</td>
																				<td>
																					<span class="js-lists-values-employee-name"><?php echo $row->product_type;?></span>
																				</td>
																				<td>
																					<span class="js-lists-values-employee-name"><?php echo $row->product_sub_type;?></span>
																				</td>
																				<td>
																					<span class="js-lists-values-employee-name"><?php echo mb_strimwidth($row->product_description, 0, 10, "...");?></span>
																				</td>
																				<td>
																					<span class="js-lists-values-employee-name"><?php echo $row->product_weight;?><?php echo $row->product_weight_type;?></span>
																				</td>

																				<td>
																					<span class="js-lists-values-employee-name"><?php echo $row->product_qty;?></span>
																				</td>
																				<td>
																					<span class="js-lists-values-employee-name">
																						<?php echo $row->product_price;?>
																					</span>
																				</td>
																				<td>
																					<span class="js-lists-values-employee-name"><?php echo $row->offer_price;?></span>
																				</td>
																				<td>
																					<span class="js-lists-values-employee-name">
																						<?php $uriSegments = explode("/", parse_url($row->product_img, PHP_URL_PATH));
																						$lastUriSegment = array_pop($uriSegments);
																						?>
																						<?php echo $lastUriSegment;?>
																					</span>
																				</td>
																				<td>
																					<span class="js-lists-values-employee-name"><?php echo date("Y-m-d",strtotime($row->product_added_date));?></span>
																				</td>
																			</tr>
																		</tbody>
																	<?php } ?>
																</table>
															</div>
														<?php }?>
													<?php }?>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="tab-pane" id="fourth">
								<br>
								<div class="card" >
									<div class="card-body">
										<div class="row">
											<div class="col-md-3">
												<span><strong>Store Name :</strong></span>
											</div>
											<div class="col-md-9">
												<?php echo $shopSummary->shop_name;?>
											</div>
										</div>
										<div class="row">
											<div class="col-md-3">
												<span><strong>Store Address :</strong></span>
											</div>
											<div class="col-md-9">
												<?php echo $shopSummary->shop_address;?>
											</div>
										</div>
										<div class="row">
											<div class="col-md-3">
												<span><strong>Store Type :</strong></span>
											</div>
											<div class="col-md-9">
												<?php if(count($shopSummaryType)>1) {?>
													<?php foreach($shopSummaryType as $sst) {?>
														<?php echo $sst->shop_type_name .'|';?>
													<?php }?>
												<?php } else {?>
													<?php foreach($shopSummaryType as $sst) {?>
														<?php echo $sst->shop_type_name;?>
													<?php }?>
												<?php }?>
											</div>
										</div>
										<div class="row">
											<div class="col-md-3">
												<span><strong>Store Unique Code :</strong></span>
											</div>
											<div class="col-md-9">
												<?php echo $shopSummary->shopId;?>
											</div>
										</div>
										<div class="row">
											<div class="col-md-3">
												<span><strong>Upload Status :</strong></span>
											</div>
											<div class="col-md-9">
												<?php if($shopSummary->upload_status=='partiallyuploadedbycustomer') { ?>
													<span>Partially uploaded by customer</span>
												<?php } elseif($shopSummary->upload_status=='fullyuploadedbycustomer') {?>
													<span>Fully uploaded by customer</span>
												<?php } elseif($shopSummary->upload_status=='notuploadedbycustomer') {?>
													<span>Not uploaded by customer</span>
												<?php } elseif($shopSummary->upload_status=='Uploaded from base DB') {?>
													<span>Uploaded from base DB</span>
												<?php } elseif($shopSummary->pharma_status=='1') {?>
													<span>Pharmacy No product displayed</span>
												<?php } else {?>
													
												<?php }?>
											</div>
										</div>
										<div class="row">
											<div class="col-md-3">
												<span><strong>No of Products :</strong></span>
											</div>
											<div class="col-md-9">
												<?php if(!empty($productCount)) {foreach($productCount as $key => $value){?>

													<?php echo $value;?>
												<?php } } ?>  
											</div>
										</div>
										<form action="<?php echo base_url('backend/MyShopController/saveStoreSummary/'.$shopId);?>" method="post">
											<div class="row">
												<div class="col-md-9">
													<span><strong>Do you wish to get updates of products added to our central repository? You can add products from here to your store</strong></span>
												</div>
												<div class="col-md-3">
													<label>
														<?php if($shopSummary->productUpdate_status==1) {?>
															<input type="checkbox" id="one" value="1" name="productUpdates" checked/> Yes
														<?php } else {?>
															<input type="checkbox" id="one" value="1" name="productUpdates" /> Yes
														<?php }?>
													</label> 
													<label>
														<?php if($shopSummary->productUpdate_status==2) {?>
															<input type="checkbox" id="two" value="2" name="productUpdates" checked/> No
														<?php } else {?>
															<input type="checkbox" id="two" value="2" name="productUpdates" /> No
														<?php }?>
													</label>
												</div>  
												<input type="hidden" calss="form-control" name="editStrInfo" value="editStrInfo">
											</div>
											<div class="row">
												<input type="submit" id="checkBtn" class="btn btn-success" name="submit" value="Save">
											</div>
										</form>
									</div>
								</div> 
							</div>

						</div>
					</div>
				</div>
				<!-- container-fluid -->
			</div>
			<!-- End Page-content -->
			<?php $this->load->view('backend/include/sidebar');?>
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script> 
		<script type="text/javascript">
		    $('#shop_name').on('keyup', function () {
				var shopName = $('#shop_name').val();
				if(shopName != '')
				{
					$.ajax({
						url:"<?php echo base_url(); ?>backend/MyShopController/fetchShopByName",
						method:"POST",
						data:{shopName:shopName},
						success:function(data)
						{
							if(data==0)
							{
								$('#message').html('Good to go').css('color', 'green');
							}
							else
							{
								$('#message').html('Shop already present').css('color', 'red');
								$("#submit").removeAttr('disabled','disabled');
							}
						}
					});
				}
      	    });
			$(document).on('click', 'input[name="productUpdates"]', function() {      
                $('input[name="productUpdates"]').not(this).prop('checked', false);      
            });
            $('#checkBtn').click(function() {
                checked = $("input[type=checkbox]:checked").length;

                if(!checked) {
                    alert("You must check at least one checkbox.");
                    return false;
                }

            });
            function copyToClipboard() {
                var inputElement=document.getElementById('input-text');
                inputElement.select();
                document.execCommand('copy');
                //alert("Copied to clipboard");
            }
            function PharmaCheck()
			{
				if (document.getElementById('yesPharma').checked) 
				{
					document.getElementById('ifYesPharma').style.display = 'block';
					document.getElementById('ifNoPharma').style.display = 'none';
					document.getElementById('ifYes').style.display = 'none';
					document.getElementById('ifComfortable').style.display = 'none';
					document.getElementById('ifExport').style.display = 'none';
					document.getElementById('ifMaybe').style.display = 'none';
					document.getElementById('ifMaybeYes').style.display = 'none';
					document.getElementById('ifMaybeExport').style.display = 'none';
					document.getElementById('ifHelp').style.display = 'none';
					document.getElementById('ifNo').style.display = 'none';
					$("input:radio[name=maybe]:checked")[0].checked = false;
				}
				else 
				{	document.getElementById('ifYesPharma').style.display = 'none';
					// document.getElementById("ifAgency").disabled = true;	
				}
				if (document.getElementById('noPharma').checked) 
				{
					document.getElementById('ifNoPharma').style.display = 'block';
					document.getElementById('ifMaybeExport').style.display = 'none';
					document.getElementById('ifMaybe').style.display = 'none';
					document.getElementById('ifMaybeYes').style.display = 'none';
					document.getElementById('ifHelp').style.display = 'none';
					document.getElementById('ifNo').style.display = 'none';
					$("input:radio[name=maybe]:checked")[0].checked = false;
				}
				else 
				{	document.getElementById('ifNoPharma').style.display = 'none';
					// document.getElementById("ifAgency").disabled = true;	
				}
			}
			function SKUCheck() 
			{
				if (document.getElementById('yes').checked) 
				{
					document.getElementById('ifYes').style.display = 'block';
					document.getElementById('ifMaybeExport').style.display = 'none';
					document.getElementById('ifMaybe').style.display = 'none';
					document.getElementById('ifMaybeYes').style.display = 'none';
					document.getElementById('ifHelp').style.display = 'none';
					document.getElementById('ifNo').style.display = 'none';
					$("input:radio[name=maybe]:checked")[0].checked = false;
				}
				else 
				{	document.getElementById('ifYes').style.display = 'none';
					// document.getElementById("ifAgency").disabled = true;	
				}
				if (document.getElementById('maybe').checked) 
				{
					document.getElementById('ifMaybe').style.display = 'block';
					document.getElementById('ifExport').style.display = 'none';
					document.getElementById('ifComfortable').style.display = 'none';
					document.getElementById('ifHelp').style.display = 'none';
					document.getElementById('ifNo').style.display = 'none';
					$("input:radio[name=yes]:checked")[0].checked = false;
					document.getElementById("ifMaybe").disabled = true;
					document.getElementById("ifComfortable").disabled = true;
					document.getElementById("ifHelp").disabled = true;
				}
				else
				{
					document.getElementById('ifMaybe').style.display = 'none';
					//document.getElementById("ifIndividual").disabled = true;
				} 

				if (document.getElementById('no').checked) 
				{
					document.getElementById('ifNo').style.display = 'block';
					document.getElementById('ifMaybeExport').style.display = 'none';
					document.getElementById('ifExport').style.display = 'none';
					document.getElementById('ifComfortable').style.display = 'none';
					document.getElementById('ifHelp').style.display = 'none';
					document.getElementById('ifMaybeYes').style.display = 'none';
					document.getElementById("ifNo").disabled = true;
					document.getElementById("ifComfortable").disabled = true;
					document.getElementById("ifHelp").disabled = true;
					$("input:radio[name=yes]:checked")[0].checked = false;
					//$("input:radio[name=maybe]:checked")[0].checked = false;
					//    var radio = document.querySelector('input[type=radio][name=maybe]:checked');
					// radio.checked = false;
				}
				else
				{
					document.getElementById('ifNo').style.display = 'none';
					//document.getElementById("ifIndividual").disabled = true;
				} 
			}
			function yesCheck() 
			{

				if (document.getElementById('comfortableCheck').checked) 
				{
					document.getElementById('ifComfortable').style.display = 'block';
					document.getElementById('ifMaybeExport').style.display = 'none';
					document.getElementById('ifMaybeYes').style.display = 'none';
					document.getElementById('ifHelp').style.display = 'none';
				}
				else 
				{	document.getElementById('ifComfortable').style.display = 'none';
					// document.getElementById("ifAgency").disabled = true;	
				}

				if (document.getElementById('helpCheck').checked) 
				{
					document.getElementById('ifHelp').style.display = 'block';
					document.getElementById('ifComfortable').style.display = 'none';
					document.getElementById("ifHelp").disabled = true;
				}
				else
				{
					document.getElementById('ifHelp').style.display = 'none';
					//document.getElementById("ifIndividual").disabled = true;
				} 
			}

			function exportCheck()
			{
				if (document.getElementById('export').click) 
				{
					document.getElementById('ifExport').style.display = 'block';
					document.getElementById('ifMaybeExport').style.display = 'none';
					var fullyByCust = 'fullyuploadedbycustomer'
					document.getElementById('fullyuploadedbycustomer').value = fullyByCust;
				}
				else 
				{	document.getElementById('ifExport').style.display = 'none';
					// document.getElementById("ifAgency").disabled = true;	
				}
			}

			function maybeCheck() 
			{
				if (document.getElementById('maybeYesCheck').checked) 
				{
					document.getElementById('ifMaybeYes').style.display = 'block';
					document.getElementById('ifMaybeExport').style.display = 'none';
				}
				else 
				{	document.getElementById('ifMaybeYes').style.display = 'none';
					// document.getElementById("ifAgency").disabled = true;	
				}

				if (document.getElementById('maybeNoCheck').checked) 
				{
					document.getElementById('ifHelp').style.display = 'block';
					document.getElementById("ifHelp").disabled = true;
				}
				else
				{
					document.getElementById('ifHelp').style.display = 'none';
					//document.getElementById("ifIndividual").disabled = true;
				} 
			}

			function maybeexportCheck()
			{
				if (document.getElementById('maybeexport').click) 
				{
					document.getElementById('ifMaybeExport').style.display = 'block';
					document.getElementById('ifExport').style.display = 'none';
					var partialByCust = 'partiallyuploadedbycustomer'
					document.getElementById('partiallyuploadedbycustomer').value = partialByCust;
				}
				else 
				{	document.getElementById('ifMaybeExport').style.display = 'none';
					// document.getElementById("ifAgency").disabled = true;	
				}
			}
		</script>
		<?php if($this->session->flashdata('flashSuccess')) { ?>
			<script type="text/javascript">
				window.setTimeout(function() {
					$(".successmsg").fadeTo(1000, 0).slideUp(500, function(){
						$(this).remove(); 
					});
				}, 3000);
			</script>
		<?php } ?>  
		<?php if($this->session->flashdata('flashError')) { ?>
			<script type="text/javascript">
				window.setTimeout(function() {
					$(".errormsg").fadeTo(900, 0).slideUp(800, function(){
						$(this).remove(); 
					});
				}, 4000);
			</script>
		<?php } ?> 
		<style>
			.fixTableHead {
				overflow-y: auto;
				height: 510px;
			}
			.NofixTableHead {
				overflow-y: auto;
				width:1000px;
			}
			.fixTableHead thead th {
				position: sticky;
				top: 0;
			}
			table {
				border-collapse: collapse;        
				width: 100%;
			}
			th,td {
				padding: 8px 15px;
				border: 2px solid #529432;
			}
			th {
				background: #ABDD93;
			}
			/*[dir=ltr] .table tbody td,*/
   /*         [dir=ltr] .table thead th {*/
   /*         	vertical-align: middle;*/
   /*         	line-height: 0.2;*/
   /*         	white-space: pre-wrap;*/
   /*         }*/
		</style>