<!-- Header Layout Content -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets1/css/fixTableHead.css');?>">
<div class="mdk-header-layout__content">
	<div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
		<div class="mdk-drawer-layout__content page ">
			<div class="container-fluid page__container">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="<?php echo base_url('Admin/dashboard')?>">Home</a></li>
					<li class="breadcrumb-item active">My Shops</li>
				</ol>
				<ul class="nav nav-tabs">
					<li class="nav-item">
						<a class="nav-link" style="cursor: pointer">Store Information</a>
					</li>
					&nbsp;
					<li class="nav-item">
						<a class="nav-link" href="#store_config" data-toggle="tab">Store Configuration</a>
					</li>
					&nbsp;
					<li class="nav-item">
						<a class="nav-link active" href="#product_config" data-toggle="tab">Product Configuration</a>
					</li>
					&nbsp;
					<li class="nav-item">
						<a class="nav-link" style="cursor: pointer">Product Information</a>
					</li>
					&nbsp;
					<li class="nav-item">
						<a class="nav-link" style="cursor: pointer">Store Summary</a>
					</li>
				</ul>
				<br>
				<div class="tab-content ">
					<div class="tab-pane" id="store_config">
						<br>
						<div class="row">
							<div class="col-sm-12">
								<div class="card">
									<div class="card-body">
										<div class="form-group">
											<div class="radio">
												<div class="ez-radio pull-left">
													<label>
														<strong>1. &nbsp; <span>I am configuring a Pharmaceutical store </span></strong>
													</label>
												</div>
												<div class="ez-radio">
													<label>
														<input type="radio" name="pharma" id="yesPharma" value="Yes" onclick="javascript:PharmaCheck();">
														Yes
													</label>
													<label>
														<input type="radio" name="pharma" id="noPharma" value="No" onclick="javascript:PharmaCheck();">
														No
													</label>
												</div>
											</div>
										</div>
										<div id="ifYesPharma" style="display:none">
											<div class="row">
												<div class="col-sm-12">
													<div class="radio">
														<div class="ez-radio pull-left">
															<label>
																<strong>2. &nbsp; <span>Pharmaceutical products will/should not be displayed to customer. Customer will have to upload their prescription</span></strong>
															</label>
															<br>
															<span style="color:red"><b>Note: Cash on Delivery will be activated as default payment method for Pharma products</b></span>
															<br>
															<br>
															<form action="<?php echo base_url('backend/MyShopController/updatePharmaStatus/'.$this->uri->segment(4));?>" method="post">
																<input type="hidden" class="form-control" value="1" name="pharmaYes">
																<input type="submit" class="btn btn-success" value="Continue" name="submit">
															</form>
														</div>
													</div>
												</div>
											</div>
											&nbsp;
										</div>
										<div id="ifNoPharma" style="display:none">
											<div class="form-group">
												<div class="radio">
													<div class="ez-radio pull-left">
														<label>
															<strong>2. &nbsp; <span>Do you have inventory (SKU) information of the products in your store? </span></strong>
														</label>
													</div>
													<div class="ez-radio">
														<label>
															<input type="radio" name="product_info" id="yes" value="Yes" onclick="javascript:SKUCheck();">
															Yes
														</label>
														<label>
															<input type="radio" name="product_info" id="maybe" value="Maybe" onclick="javascript:SKUCheck();">
															Maybe
														</label>
														<label>
															<input type="radio" name="product_info" id="no" value="No" onclick="javascript:SKUCheck();">
															No
														</label>
													</div>
												</div>
											</div>
										</div>
										<div id="ifYes" style="display:none">
											<div class="row">
												<div class="col-sm-12">
													<div class="radio">
														<div class="ez-radio pull-left">
															<label>
																<strong>3. &nbsp; <span>Would you be comfortable in uploading your store products by yourself or would you want assistance from Direct-Buy team? </span></strong>
															</label>
														</div>

														<div class="ez-radio pull-left">
															<label>
																<input type="radio" onclick="javascript:yesCheck();" name="yes" value="I am comfortable" id="comfortableCheck">
																I am comfortable
															</label>
															<label>
																<input type="radio" onclick="javascript:yesCheck();" name="yes" value="I need help" id="helpCheck">
																I need help
															</label>
														</div>
													</div>
												</div>
											</div>
											&nbsp;
										</div>

										<div id="ifComfortable" style="display:none">
											<div class="row">
												<div class="col-sm-12">
													<div class="radio">
														<div class="ez-radio pull-left">
															<label>
																<strong>4. &nbsp; <span>Click here to download the template to upload your products data to your store</span></strong>
															</label>
														</div>
														<div class="col-md-6">
															
															<form method="post" action="<?php echo base_url('backend/ExportExcelController/exportProductDataFromBaseDB/');?>">
																<input type="submit" name="export" class="btn btn-success" value="Export" onclick="javascript:exportCheck();" id="export"/>
															</form>
														</div>
													</div>
												</div>
											</div>
											&nbsp;
										</div>
										<div id="ifExport" style="display:none">
											<div class="row">
												<div class="col-sm-12">
													<div class="radio">
														<div class="ez-radio pull-left">
															<label>
																<strong>5. &nbsp; <span>Fill out the data and upload the file</span></strong>
															</label>
														</div>

														<form action="<?php echo base_url('backend/ImportExcelController/importProductDataToBaseDB/'.$this->uri->segment(4));?>" method="post" enctype="multipart/form-data">
															<div class="row">
																<div class="col-md-6">
																	<input type="file" class="form-control" name="uploadFile"/>

																	<input type="hidden" value="" id="fullyuploadedbycustomer" name="fullyuploadedbycustomer">
																</div>
																<div class="col-md-2">
																	<input type="submit" name="submit" class="btn btn-success" value="Import"/>
																</div>
															</div>
														</form>
													</div>
												</div>
											</div>
											&nbsp;
										</div>

										<div id="ifMaybe" style="display:none">
											<div class="row">
												<div class="col-sm-12">
													<div class="radio">
														<div class="ez-radio pull-left">
															<label>
																<strong>3. &nbsp; <span>Would you confirm you have some data, but not all data?</span></strong>
															</label>
														</div>

														<div class="ez-radio pull-left">
															<label>
																<input type="radio" onclick="javascript:maybeCheck();" name="maybe" value="Yes" id="maybeYesCheck">
																Yes
															</label>
															<label>
																<input type="radio" onclick="javascript:maybeCheck();" name="maybe" value="No" id="maybeNoCheck">
																No
															</label>
														</div>
													</div>
												</div>
											</div>
											&nbsp;
										</div>
										<div id="ifMaybeYes" style="display:none">
											<div class="row">
												<div class="col-sm-12">
													<div class="radio">
														<div class="ez-radio pull-left">
															<label>
																<strong>4. &nbsp; <span>Click here to download the template to upload your products data to your store.</span></strong>
															</label>
														</div>
														<div class="col-md-6">
															<form method="post" action="<?php echo base_url('backend/ExportExcelController/exportProductDataFromBaseDB/');?>">
																<input type="submit" name="export" class="btn btn-success" value="Export" onclick="javascript:maybeexportCheck();" id="maybeexport"/>
															</form>
														</div>
													</div>
												</div>
											</div>
											&nbsp;
										</div>
										<div id="ifMaybeExport" style="display:none">
											<div class="row">
												<div class="col-sm-12">
													<div class="radio">
														<div class="ez-radio pull-left">
															<label>
																<strong>5. &nbsp; <span>Fill out the data and upload the file partially</span></strong>
															</label>
														</div>
														<form action="<?php echo base_url('backend/ImportExcelController/importProductDataToBaseDB/'.$this->uri->segment(4));?>" method="post" enctype="multipart/form-data">
															<div class="row">
																<div class="col-md-6">
																	<input type="file" class="form-control" name="uploadFile"/>
																	<input type="hidden" value="" id="partiallyuploadedbycustomer" name="partiallyuploadedbycustomer">
																</div>
																<div class="col-md-2">
																	<input type="submit" name="submit" class="btn btn-success" value="Import"/>
																</div>
															</div>
														</form>
														<span><b>Note: You can also reach out to dataupload@direct-buy.in for data that you do not have.</b></span>
														
													</div>
												</div>
											</div>
											&nbsp;
										</div>
										<div id="ifHelp" style="display:none">
											<form action="<?php echo base_url('backend/MyShopController/continueWithoutProductUpload/'.$this->uri->segment(4));?>" method="post" >
												<div class="row">
													<div class="col-sm-12">
														<div class="radio">
															<div class="ez-radio pull-left">
																<label>
																	<strong>4. &nbsp; <span>Please email your products database to dataupload@direct-buy.in</span></strong>
																</label>
															</div>
														</div>
													</div>
												</div>
												<input type="submit" class="btn btn-success" value="Continue" name="submit">
											</form>
											&nbsp;
										</div>
										<div id="ifNo" style="display:none">
											<div class="row">
												<div class="col-sm-12">
													<div class="radio">
														<div class="ez-radio pull-left">
															<label>
																<span><strong>“Direct-buy will provide you with limited information of products that Direct-Buy holds in its central database. This database is every growing and we keep up updated with more products as they get added to our central database. You can reach out to dataupload@direct-buy.in for data upload.” &nbsp;</strong></span>
															</label>
														</div>
													</div>
												</div>
												<form action="<?php echo base_url('backend/MyShopController/strProductConfig/'.$this->uri->segment(4).'/'.'datafrombaseDB');?>" method="post" >
													<input type="submit" class="btn btn-success" value="Continue" name="submit">
												</form>
											</div>
											&nbsp;
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-pane active" id="product_config">
						<div class="row">
							<div class="col-lg-12">
								<div class="card">
									<div class="card-body">
										<div class="fixTableHead">
											<table id="mytable" class="w3-table-all record_table">
												<thead>
													<tr>
														<th>Category</th>
														<th>SubCategory</th>
														<th>Brand</th>
														<th style="width:100px;"><input type="button" id="save_value" name="save_value" value="Add" style="height:25px" /></th>
													</tr>
												</thead>
												<tbody>
													<?php foreach($baseProducts as $row) {?>
														<tr>
															<td><?php echo $row['category'];?></td>
															<td><?php echo $row['sub_category'];?></td>
															<td><?php echo $row['brand'];?></td>
															<!-- <td>
																<input type="button" class="btn btn-success adddata" value="Add" id="<?=$row['base_product_id']?>">
															</td> -->
															<td>
																<input type="checkbox" class="adddata" name="chk[]" value="<?=$row['base_product_id']?>" id="<?=$row['base_product_id']?>" checked>
															</td>
														</tr>
													<?php }?>
												</tbody>
											</table>
										</div>
										<hr>
										<h3>List of Products</h3>
	                           <form name="frm-example" id="frm-example" method="POST">
	                               <div class="row">
	                                   <div class="col-md-6">
	                                       <span id='message' ></span>
	                                   </div>
	                                   <div class="col-md-4">
	                                       <img id="bigpic" src="<?php echo base_url('assets1/img/Flat_hourglass.gif');?>" style="display:none"/>
	                                   </div>
	                               </div>
	                              <div class="NofixTableHead">
	                                 <table id="example" class="table table-centered table-nowrap display">
	                                 	<thead class="thead-light">
	                                 		<tr>
	                                 			<th>Id</th>
	                                 			<th>SKU</th>
	                                 			<th>Category</th>
	                                 			<th>SubCategory</th>
	                                 			<th>Brand</th>
	                                 			<th>Name</th>
	                                 			<th>Type</th>
	                                 			<th>SubType</th>
	                                 			<th>Description</th>
	                                 			<th>Weight</th>
	                                 			<th>SubWeight</th>
	                                 			<th>Qty</th>
	                                 			<th>Price</th>
	                                 			<th>OfferPrice</th>
	                                 			<th>Img</th>
	                                 		</tr>
	                                 	</thead>
	                                 	<tbody id="displayArea"></tbody>
	                                 	<tbody>
	                                 		<tr>
	                                 			<td>
	                                 				<input class="btn btn-success" type="button" value="Submit" id="QAdddata" >
	                                 			</td>
	                                 		</tr>
	                                 	</tbody>
	                                 </table>
	                              </div>
	                           </form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- container-fluid -->
		</div>
		<!-- End Page-content -->
		<?php $this->load->view('backend/include/sidebar');?>
		<script type="text/javascript" src="<?php echo base_url('assets1/js/jquery.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets1/js/ddtf.js');?>"></script>
		<script type="text/javascript">
			$('#mytable').ddTableFilter();
			$(document).ready(function() {
				$('.record_table tr').click(function(event) {
					if (event.target.type !== 'checkbox') {
						$(':checkbox', this).trigger('click');
					}
				});
			});
		</script>
		<script type="text/javascript">
			$(document).ready(function(){
				$('#save_value').click(function(){
		        	var val = [];
	        		$(':checkbox:checked').each(function(i){
	        		    val[i] = $(this).val();
		        		var id = val[i];
		        		//alert(id);
		        		var URL = window.location.href;
						var arr=URL.split('/');
						var storeId = arr[6];
						if (id != '')
	        			{
	        			    $.ajax({
        	               		url:"<?php echo base_url(); ?>backend/MyShopController/fetchBaseProductsById",
        	               		method:"POST",
        	               		data:{id:id},
        	               		success:function(data)
        	               		{
        	               			var obj = jQuery.parseJSON(data);
        	               			console.log(obj);
        	               			$.each(obj, function(i, item) {
        	               			    var rows = "";
        	               				var db_SKU = obj[i].db_SKU;
            				        	var category = obj[i].category;
            				        	var sub_category = obj[i].sub_category;
            				        	var brand = obj[i].brand;
            				        	var product_name = obj[i].product_name;
            				        	var product_type = obj[i].product_type;
            				        	var product_sub_type = obj[i].product_sub_type;
            				        	var product_description = obj[i].product_description;
            				        	// var result = stringDivider(product_description, 40, "<br/>\n");
            				        	//var productDesc = product_description.substring(0,10)
            				        	var product_weight = obj[i].product_weight;
            				        	var product_weight_type = obj[i].product_weight_type;
            				        	var product_qty = obj[i].product_qty;
            				        	var product_price = obj[i].product_price;
            				        	var offer_price = obj[i].offer_price;
            				        	var product_img = obj[i].product_img;
            				        	
            				        	rows += "<tr data-index="+ id +"><td>" + db_SKU + "</td><td>" + category + "</td><td>" + sub_category + "</td><td>" + brand + "</td><td>" + product_name + "</td><td>" + product_type + "</td><td>" + product_sub_type + "</td><td>" + product_description + "</td><td>" + product_weight + "</td><td>" + product_weight_type + "</td><td>" + product_qty + "</td><td>" + product_price + "</td><td>" + offer_price + "</td><td>" + product_img + "</td></tr>";
        	                    		$(rows).appendTo("#displayArea");
        	                    		$('#QAdddata').click(function(){
        	                    		    $('#message').html('Data is getting uploaded please wait while we finish uploading the data and take you back').css('color', 'red');
        	                        	    document.getElementById('bigpic').style.display='block';
        	                        	    $('#QAdddata').prop('disabled',true);
        	                        	    checkData(storeId,db_SKU,category,sub_category,brand,product_name,product_type,product_sub_type,product_description,product_weight,product_weight_type,product_qty,product_price,offer_price,product_img);
        	                    		});
        							 });
        					    }
	               	        });
	        			}
					});
	        	});

				function checkData(storeId,db_SKU,category,sub_category,brand,product_name,product_type,product_sub_type,product_description,product_weight,product_weight_type,product_qty,product_price,offer_price,product_img)
				{
					var storeid = storeId;
					var sku = db_SKU;
					var cat = category;
					var subcat = sub_category;
					var brand = brand;
					var productName = product_name;
					var productType = product_type;
					var productSubType = product_sub_type;
					var productDescription = product_description;
					var productWeight = product_weight;
					var productWeightType = product_weight_type;
					var productQty = product_qty;
					var productPrice = product_price;
					var offerPrice = offer_price;
					var productImg = product_img;

					$.ajax({
						url:"<?php echo base_url(); ?>backend/MyShopController/checkBaseProductInTemp",
						method:"POST",
						data:{storeid:storeid},
						success:function(data)
						{
						    submitData(storeId,db_SKU,category,sub_category,brand,product_name,product_type,product_sub_type,product_description,product_weight,product_weight_type,product_qty,product_price,offer_price,product_img);
				// 			if(data==1)
				// 			{
				// 				$.ajax({
				// 					url:"<?php echo base_url(); ?>backend/MyShopController/saveBaseProductsToTemp",
				// 					method:"POST",
				// 					data:{storeid:storeid,sku:sku,cat:cat,subcat:subcat,brand:brand,productName:productName,productType:productType,productSubType:productSubType,productDescription:productDescription,productWeight:productWeight,productWeightType:productWeightType,productQty:productQty,productPrice:productPrice,offerPrice:offerPrice,productImg:productImg},
				// 					success:function(data)
				// 					{
				// 						//location.reload(true);
				// 						// var object = jQuery.parseJSON(data);
				// 						// console.log(object);
				// 						if(data==1){
				// 						    var base_url = window.location.origin;
    //                                         window.location.href= base_url +'/backend/MyShopController/viewProductsByShopId/'+storeid+'/datafrombaseDB/';
                           
				// 							//window.location.href= 'http://localhost:8080/public_html/asma/backend/MyShopController/viewProductsByShopId/'+storeid+'/datafrombaseDB';
				// 						}
				// 						else{
				// 						    var base_url = window.location.origin;
    //                                         window.location.href= base_url +'/backend/MyShopController/strProductConfig/'+storeid+'/datafrombaseDB/';
				// 							//window.location.href= 'http://localhost:8080/public_html/asma/backend/MyShopController/strProductConfig/'+storeid+'/datafrombaseDB';
				// 						}
				// 					}
				// 				});
				// 			}
						}
					});
				}
				function submitData(storeId,db_SKU,category,sub_category,brand,product_name,product_type,product_sub_type,product_description,product_weight,product_weight_type,product_qty,product_price,offer_price,product_img)
				{
					var storeid = storeId;
					var sku = db_SKU;
					var cat = category;
					var subcat = sub_category;
					var brand = brand;
					var productName = product_name;
					var productType = product_type;
					var productSubType = product_sub_type;
					var productDescription = product_description;
					var productWeight = product_weight;
					var productWeightType = product_weight_type;
					var productQty = product_qty;
					var productPrice = product_price;
					var offerPrice = offer_price;
					var productImg = product_img;
					
					$.ajax({
						url:"<?php echo base_url(); ?>backend/MyShopController/saveBaseProductsToTemp",
						method:"POST",
						dataType: "json",
						data:{'storeid': JSON.stringify(storeid),'sku': JSON.stringify(sku),'cat': JSON.stringify(cat),'subcat': JSON.stringify(subcat),'brand': JSON.stringify(brand),'productName': JSON.stringify(productName),'productType': JSON.stringify(productType),'productSubType': JSON.stringify(productSubType),'productDescription': JSON.stringify(productDescription),'productWeight': JSON.stringify(productWeight),'productWeightType': JSON.stringify(productWeightType),'productQty': JSON.stringify(productQty),'productPrice': JSON.stringify(productPrice),'offerPrice': JSON.stringify(offerPrice),'productImg': JSON.stringify(productImg)},
						success:function(data)
						{
						    console.log(data);
							if(data==1){
							    setTimeout(function () {
                                    var base_url = window.location.origin;
                                    window.location.href= base_url +'/backend/MyShopController/viewProductsByShopId/'+storeid+'/datafrombaseDB';
                                }, 50000);
                            }
							else{
							    var base_url = window.location.origin;
							    window.location.href= base_url +'/backend/MyShopController/strProductConfig/'+storeid+'/datafrombaseDB';
								
							}
						}
					});
				}
			});
		</script>
		<script type="text/javascript">
			function PharmaCheck()
			{
				if (document.getElementById('yesPharma').checked)
				{
					document.getElementById('ifYesPharma').style.display = 'block';
					document.getElementById('ifNoPharma').style.display = 'none';
					document.getElementById('ifYes').style.display = 'none';
					document.getElementById('ifComfortable').style.display = 'none';
					document.getElementById('ifExport').style.display = 'none';
					document.getElementById('ifMaybe').style.display = 'none';
					document.getElementById('ifMaybeYes').style.display = 'none';
					document.getElementById('ifMaybeExport').style.display = 'none';
					document.getElementById('ifHelp').style.display = 'none';
					document.getElementById('ifNo').style.display = 'none';
					$("input:radio[name=maybe]:checked")[0].checked = false;
				}
				else{	
					document.getElementById('ifYesPharma').style.display = 'none';
				}
				if (document.getElementById('noPharma').checked) 
				{
					document.getElementById('ifNoPharma').style.display = 'block';
					document.getElementById('ifMaybeExport').style.display = 'none';
					document.getElementById('ifMaybe').style.display = 'none';
					document.getElementById('ifMaybeYes').style.display = 'none';
					document.getElementById('ifHelp').style.display = 'none';
					document.getElementById('ifNo').style.display = 'none';
					$("input:radio[name=maybe]:checked")[0].checked = false;
				}
				else{	document.getElementById('ifNoPharma').style.display = 'none';
				}
			}
			function SKUCheck() 
			{
				if (document.getElementById('yes').checked) 
				{
					document.getElementById('ifYes').style.display = 'block';
					document.getElementById('ifMaybeExport').style.display = 'none';
					document.getElementById('ifMaybe').style.display = 'none';
					document.getElementById('ifMaybeYes').style.display = 'none';
					document.getElementById('ifHelp').style.display = 'none';
					document.getElementById('ifNo').style.display = 'none';
					$("input:radio[name=maybe]:checked")[0].checked = false;
				}
				else{	document.getElementById('ifYes').style.display = 'none';
				}
				if (document.getElementById('maybe').checked) 
				{
					document.getElementById('ifMaybe').style.display = 'block';
					document.getElementById('ifExport').style.display = 'none';
					document.getElementById('ifComfortable').style.display = 'none';
					document.getElementById('ifHelp').style.display = 'none';
					document.getElementById('ifNo').style.display = 'none';
					$("input:radio[name=yes]:checked")[0].checked = false;
					document.getElementById("ifMaybe").disabled = true;
					document.getElementById("ifComfortable").disabled = true;
					document.getElementById("ifHelp").disabled = true;
				}
				else
				{
					document.getElementById('ifMaybe').style.display = 'none';
				} 

				if (document.getElementById('no').checked) 
				{
					document.getElementById('ifNo').style.display = 'block';
					document.getElementById('ifMaybeExport').style.display = 'none';
					document.getElementById('ifExport').style.display = 'none';
					document.getElementById('ifComfortable').style.display = 'none';
					document.getElementById('ifHelp').style.display = 'none';
					document.getElementById('ifMaybeYes').style.display = 'none';
					document.getElementById("ifNo").disabled = true;
					document.getElementById("ifComfortable").disabled = true;
					document.getElementById("ifHelp").disabled = true;
					$("input:radio[name=yes]:checked")[0].checked = false;
				}
				else
				{
					document.getElementById('ifNo').style.display = 'none';
				} 
			}
			function yesCheck() 
			{

				if (document.getElementById('comfortableCheck').checked) 
				{
					document.getElementById('ifComfortable').style.display = 'block';
					document.getElementById('ifMaybeExport').style.display = 'none';
					document.getElementById('ifMaybeYes').style.display = 'none';
					document.getElementById('ifHelp').style.display = 'none';
				}
				else{	document.getElementById('ifComfortable').style.display = 'none';
				}

				if (document.getElementById('helpCheck').checked) 
				{
					document.getElementById('ifHelp').style.display = 'block';
					document.getElementById('ifComfortable').style.display = 'none';
					document.getElementById("ifHelp").disabled = true;
				}
				else
				{
					document.getElementById('ifHelp').style.display = 'none';
				} 
			}

			function exportCheck()
			{
				if (document.getElementById('export').click) 
				{
					document.getElementById('ifExport').style.display = 'block';
					document.getElementById('ifMaybeExport').style.display = 'none';
					var fullyByCust = 'fullyuploadedbycustomer'
					document.getElementById('fullyuploadedbycustomer').value = fullyByCust;
				}
				else {	document.getElementById('ifExport').style.display = 'none';
				}
			}

			function maybeCheck() 
			{
				if (document.getElementById('maybeYesCheck').checked) 
				{
					document.getElementById('ifMaybeYes').style.display = 'block';
					document.getElementById('ifMaybeExport').style.display = 'none';
				}
				else{	document.getElementById('ifMaybeYes').style.display = 'none';
				}

				if (document.getElementById('maybeNoCheck').checked) 
				{
					document.getElementById('ifHelp').style.display = 'block';
					document.getElementById("ifHelp").disabled = true;
				}
				else
				{
					document.getElementById('ifHelp').style.display = 'none';
				} 
			}

			function maybeexportCheck()
			{
				if (document.getElementById('maybeexport').click) 
				{
					document.getElementById('ifMaybeExport').style.display = 'block';
					document.getElementById('ifExport').style.display = 'none';
					var partialByCust = 'partiallyuploadedbycustomer'
					document.getElementById('partiallyuploadedbycustomer').value = partialByCust;
				}
				else 
				{			
					document.getElementById('ifMaybeExport').style.display = 'none';
				}
			}
		</script>