
<div class="mdk-header-layout__content">
	<div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
		<div class="mdk-drawer-layout__content page ">
			<div class="container-fluid page__container">
				<?php if($this->session->flashdata('flashSuccess')) { ?>
					<div style="width: 30%;margin-top: -4%;z-index: 1;margin-left: 35%;" class="alert alert-dismissible bg-success text-white border-0 fade show successmsg" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
						<?php echo $this->session->flashdata("flashSuccess"); ?>
					</div>
				<?php } ?> 
				<?php if($this->session->flashdata('flashError')) { ?>
					<div style="width: 30%;margin-top: -4%;z-index: 1;margin-left: 35%;" class="alert alert-dismissible bg-danger text-white border-0 fade show errormsg" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
						<?php echo $this->session->flashdata("flashError"); ?>
					</div>
				<?php } ?>
				<br>
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="<?php echo base_url('backend/MyShopController/index')?>">Home</a></li>
					<li class="breadcrumb-item active">Add Shops</li>
				</ol>
				<h1 class="h2">Add Shop</h1>
				<ul class="nav nav-tabs">
					<li class="nav-item">
						<a class="nav-link" style="cursor: pointer">Store Information</a>
					</li>
					&nbsp;
					<li class="nav-item">
						<a class="nav-link" href="#store_config" data-toggle="tab">Store Configuration</a>
					</li>
					&nbsp;
					<?php if($this->uri->segment(5)=='datafrombaseDB') {?>
						<li class="nav-item">
							<a class="nav-link" href="<?php echo base_url('backend/MyShopController/strProductConfig/'.$shopId.'/'.$proConfig);?>">Product Configuration</a>
							
						</li>
					<?php } else {?>
						<li class="nav-item">
							<a class="nav-link"  style="cursor: pointer">Product Configuration</a>
						</li>
					<?php }?>
					&nbsp;
					<li class="nav-item">
						<a class="nav-link active" href="#product_information" data-toggle="tab">Product Information</a>
					</li>
					&nbsp;
					<li class="nav-item">
						<a class="nav-link" style="cursor: pointer">Store Summary</a>
					</li>
				</ul>
				<!-- <br> -->
				<div class="">
					<div class="tab-content ">
						<div class="tab-pane" id="store_config">
							<br>
							<div class="row">
								<div class="col-sm-12">
									<div class="card">
										<div class="card-body">
											<div class="form-group">
												<div class="radio">
													<div class="ez-radio pull-left">
														<label>
															<strong>1. &nbsp; <span>I am configuring a Pharmaceutical store </span></strong>
														</label>
													</div>
													<div class="ez-radio">
														<label>
															<input type="radio" name="pharma" id="yesPharma" value="Yes" onclick="javascript:PharmaCheck();">
															Yes
														</label>
														<label>
															<input type="radio" name="pharma" id="noPharma" value="No" onclick="javascript:PharmaCheck();">
															No
														</label>
													</div>
												</div>
											</div>
											<div id="ifYesPharma" style="display:none">
												<div class="row">
													<div class="col-sm-12">
														<div class="radio">
															<div class="ez-radio pull-left">
																<label>
																	<strong>2. &nbsp; <span>Pharmaceutical products will/should not be displayed to customer. Customer will have to upload their prescription</span></strong>
																</label>
																<br>
																<span style="color:red"><b>Note: Cash on Delivery will be activated as default payment method for Pharma products</b></span>
																<br>
																<br>
																<form action="<?php echo base_url('backend/MyShopController/updatePharmaStatus/'.$this->uri->segment(4));?>" method="post">
																	<input type="hidden" class="form-control" value="1" name="pharmaYes">
																	<input type="submit" class="btn btn-success" value="Continue" name="submit">
																</form>
															</div>
														</div>
													</div>
												</div>
												&nbsp;
											</div>
											<div id="ifNoPharma" style="display:none">
												<div class="form-group">
													<div class="radio">
														<div class="ez-radio pull-left">
															<label>
																<strong>2. &nbsp; <span>Do you have inventory (SKU) information of the products in your store? </span></strong>
															</label>
														</div>
														<div class="ez-radio">
															<label>
																<input type="radio" name="product_info" id="yes" value="Yes" onclick="javascript:SKUCheck();">
																Yes
															</label>
															<label>
																<input type="radio" name="product_info" id="maybe" value="Maybe" onclick="javascript:SKUCheck();">
																Maybe
															</label>
															<label>
																<input type="radio" name="product_info" id="no" value="No" onclick="javascript:SKUCheck();">
																No
															</label>
														</div>
													</div>
												</div>
											</div>
											<div id="ifYes" style="display:none">
												<div class="row">
													<div class="col-sm-12">
														<div class="radio">
															<div class="ez-radio pull-left">
																<label>
																	<strong>3. &nbsp; <span>Would you be comfortable in uploading your store products by yourself or would you want assistance from Direct-Buy team? </span></strong>
																</label>
															</div>

															<div class="ez-radio pull-left">
																<label>
																	<input type="radio" onclick="javascript:yesCheck();" name="yes" value="I am comfortable" id="comfortableCheck">
																	I am comfortable
																</label>
																<label>
																	<input type="radio" onclick="javascript:yesCheck();" name="yes" value="I need help" id="helpCheck">
																	I need help
																</label>
															</div>
														</div>
													</div>
												</div>
												&nbsp;
											</div>

											<div id="ifComfortable" style="display:none">
												<div class="row">
													<div class="col-sm-12">
														<div class="radio">
															<div class="ez-radio pull-left">
																<label>
																	<strong>4. &nbsp; <span>Click here to download the template to upload your products data to your store</span></strong>
																</label>
															</div>
															<div class="col-md-6">
																
																<form method="post" action="<?php echo base_url('backend/ExportExcelController/exportProductDataFromBaseDB/');?>">
																	<input type="submit" name="export" class="btn btn-success" value="Export" onclick="javascript:exportCheck();" id="export"/>
																</form>
															</div>
														</div>
													</div>
												</div>
												&nbsp;
											</div>
											<div id="ifExport" style="display:none">
												<div class="row">
													<div class="col-sm-12">
														<div class="radio">
															<div class="ez-radio pull-left">
																<label>
																	<strong>5. &nbsp; <span>Fill out the data and upload the file</span></strong>
																</label>
															</div>

															<form action="<?php echo base_url('backend/ImportExcelController/importProductDataToBaseDB/'.$this->uri->segment(4));?>" method="post" enctype="multipart/form-data">
																<div class="row">
																	<div class="col-md-6">
																		<input type="file" class="form-control" name="uploadFile"/>

																		<input type="hidden" value="" id="fullyuploadedbycustomer" name="fullyuploadedbycustomer">
																	</div>
																	<div class="col-md-2">
																		<input type="submit" name="submit" class="btn btn-success" value="Import"/>
																	</div>
																</div>
															</form>
														</div>
													</div>
												</div>
												&nbsp;
											</div>

											<div id="ifMaybe" style="display:none">
												<div class="row">
													<div class="col-sm-12">
														<div class="radio">
															<div class="ez-radio pull-left">
																<label>
																	<strong>3. &nbsp; <span>Would you confirm you have some data, but not all data?</span></strong>
																</label>
															</div>

															<div class="ez-radio pull-left">
																<label>
																	<input type="radio" onclick="javascript:maybeCheck();" name="maybe" value="Yes" id="maybeYesCheck">
																	Yes
																</label>
																<label>
																	<input type="radio" onclick="javascript:maybeCheck();" name="maybe" value="No" id="maybeNoCheck">
																	No
																</label>
															</div>
														</div>
													</div>
												</div>
												&nbsp;
											</div>
											<div id="ifMaybeYes" style="display:none">
												<div class="row">
													<div class="col-sm-12">
														<div class="radio">
															<div class="ez-radio pull-left">
																<label>
																	<strong>4. &nbsp; <span>Click here to download the template to upload your products data to your store.</span></strong>
																</label>
															</div>
															<div class="col-md-6">
																<form method="post" action="<?php echo base_url('backend/ExportExcelController/exportProductDataFromBaseDB/');?>">
																	<input type="submit" name="export" class="btn btn-success" value="Export" onclick="javascript:maybeexportCheck();" id="maybeexport"/>
																</form>
															</div>
														</div>
													</div>
												</div>
												&nbsp;
											</div>
											<div id="ifMaybeExport" style="display:none">
												<div class="row">
													<div class="col-sm-12">
														<div class="radio">
															<div class="ez-radio pull-left">
																<label>
																	<strong>5. &nbsp; <span>Fill out the data and upload the file partially</span></strong>
																</label>
															</div>
															<form action="<?php echo base_url('backend/ImportExcelController/importProductDataToBaseDB/'.$this->uri->segment(4));?>" method="post" enctype="multipart/form-data">
																<div class="row">
																	<div class="col-md-6">
																		<input type="file" class="form-control" name="uploadFile"/>
																		<input type="hidden" value="" id="partiallyuploadedbycustomer" name="partiallyuploadedbycustomer">
																	</div>
																	<div class="col-md-2">
																		<input type="submit" name="submit" class="btn btn-success" value="Import"/>
																	</div>
																</div>
															</form>
															<span><b>Note: You can also reach out to dataupload@direct-buy.in for data that you do not have.</b></span>
															
														</div>
													</div>
												</div>
												&nbsp;
											</div>
											<div id="ifHelp" style="display:none">
												<form action="<?php echo base_url('backend/MyShopController/continueWithoutProductUpload/'.$this->uri->segment(4));?>" method="post" >
													<div class="row">
														<div class="col-sm-12">
															<div class="radio">
																<div class="ez-radio pull-left">
																	<label>
																		<strong>4. &nbsp; <span>Please email your products database to dataupload@direct-buy.in</span></strong>
																	</label>
																</div>
															</div>
														</div>
													</div>
													<input type="submit" class="btn btn-success" value="Continue" name="submit">
												</form>
												&nbsp;
											</div>
											<div id="ifNo" style="display:none">
												<div class="row">
													<div class="col-sm-12">
														<div class="radio">
															<div class="ez-radio pull-left">
																<label>
																	<span><strong>“Direct-buy will provide you with limited information of products that Direct-Buy holds in its central database. This database is every growing and we keep up updated with more products as they get added to our central database. You can reach out to dataupload@direct-buy.in for data upload.” &nbsp;</strong></span>
																</label>
															</div>
														</div>
													</div>
													<form action="<?php echo base_url('backend/MyShopController/strProductConfig/'.$this->uri->segment(4).'/'.'datafrombaseDB');?>" method="post" >
														<input type="submit" class="btn btn-success" value="Continue" name="submit">
													</form>
												</div>
												&nbsp;
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						
						<div class="tab-pane active" id="product_information">
							<br>
							<div class="row">
								<div class="col-sm-12">
									<div class="card">
										<div class="card-body">
										    <?php if($this->uri->segment(5)=='datafrombaseDB') {?>
												<a href="<?php echo base_url('backend/MyShopController/strProductConfig/'.$shopId.'/'.$proConfig);?>" class="btn btn-info">Back</a>
												<a href="<?php echo base_url('backend/MyShopController/storeSummary/'.$shopId.'/'.$proConfig);?>" class="btn btn-info">Continue</a>
											<?php } else {?>
												<a href="<?php echo base_url('backend/MyShopController/configureStore/'.$shopId);?>" class="btn btn-info">Back</a>
												<a href="<?php echo base_url('backend/MyShopController/storeSummary/'.$shopId);?>" class="btn btn-info">Continue</a>
											<?php }?>
												
											<div style="float:right;">
												<?php if($this->uri->segment(5)=='datafrombaseDB') {?>
													<div class="row">
														<div class="col-md-3">
															<form method="post" action="<?php echo base_url('backend/ExportExcelController/exportProductDataFromTemp/'.$shopId);?>">
																<input type="submit" name="export" class="btn btn-success" value="Export"/>
															</form>
														</div>
														<div class="col-md-9">
															<form action="<?php echo base_url('backend/ImportExcelController/importUpdatedProductDataToTemp/'.$shopId.'/'.$proConfig);?>" method="post" enctype="multipart/form-data">
																<div class="row">
																	<div class="col-md-7">
																		<input type="file" class="form-control" name="uploadFile"/>
																	</div>
																	<div class="col-md-1">
																		<input type="submit" name="submit" class="btn btn-success" value="Import"/>
																	</div>
																</div>
															</form>
														</div>
													</div>
													
												<?php } else {?>
													
												<?php }?>
											</div>
											<div class="table-responsive border-bottom" data-toggle="lists" data-lists-values='["js-lists-values-employee-name"]'>
												<br>
												<?php if($this->uri->segment(5)=='notuploadedbycustomer') {?>
													<h2>No products uploaded</h2>
												<?php } elseif($this->uri->segment(5)==1) {?>
													<h2>No products uploaded for pharmacy</h2>
												<?php } else {?>
													<?php if(empty($shopProducts)) { ?>
														<div class="NofixTableHead">
															<table class="table" >
																<thead>
																	<tr>
																		<th>Category</th>
																		<th>SubCategory</th>
																		<th>Brand</th>
																		<th>Product_Name</th>
																		<th>Product_Type</th>
																		<th>Product_SubType </th>
																		<th>Product_Description</th>
																		<th>Product_Weight</th>
																		<th>Product_Qty</th>
																		<th>Product_Price</th>
																		<th>Offer_Price</th>
																		<th>Product_Image</th>
																		<th>Product_Added_Date</th>
																	</tr>
																</thead>
																<tbody>
																	<tr>
																		<td colspan="6">Products(s) not found...</td>
																	</tr>
																</tbody>
															</table>
														</div>
													<?php } else{ ?>
														<div class="fixTableHead">
															<table class="table" >
																<thead>
																	<tr>
																		<th>Category</th>
																		<th>SubCategory</th>
																		<th>Brand</th>
																		<th>Product_Name</th>
																		<th>Product_Type</th>
																		<th>Product_SubType </th>
																		<th>Product_Description</th>
																		<th>Product_Weight</th>
																		<th>Product_Qty</th>
																		<th>Product_Price</th>
																		<th>Offer_Price</th>
																		<th>Product_Image</th>
																		<th>Product_Added_Date</th>
																	</tr>
																</thead>
																<?php $i=1; foreach ($shopProducts as $key => $row) { ?>
																	<tbody>
																		<tr>
																			<td>
																				<span class="js-lists-values-employee-name"><?php echo $row->category;?></span>
																			</td>
																			<td>
																				<span class="js-lists-values-employee-name"><?php echo $row->sub_category;?></span>
																			</td>
																			<td>
																				<span class="js-lists-values-employee-name"><?php echo $row->brand;?></span>
																			</td>
																			<td>
																				<span class="js-lists-values-employee-name"><?php echo $row->product_name;?></span>
																			</td>
																			<td>
																				<span class="js-lists-values-employee-name"><?php echo $row->product_type;?></span>
																			</td>
																			<td>
																				<span class="js-lists-values-employee-name"><?php echo $row->product_sub_type;?></span>
																			</td>
																			<td>
																				<span class="js-lists-values-employee-name"><?php echo mb_strimwidth($row->product_description, 0, 80, "...");?></span>
																			</td>
																			<td>
																				<span class="js-lists-values-employee-name"><?php echo $row->product_weight;?><?php echo $row->product_weight_type;?></span>
																			</td>

																			<td>
																				<span class="js-lists-values-employee-name"><?php echo $row->product_qty;?></span>
																			</td>
																			<td>
																				<span class="js-lists-values-employee-name">
																					<?php echo $row->product_price;?>
																				</span>
																			</td>
																			<td>
																				<span class="js-lists-values-employee-name"><?php echo $row->offer_price;?></span>
																			</td>
																			<td>
																				<span class="js-lists-values-employee-name">
																					<?php $uriSegments = explode("/", parse_url($row->product_img, PHP_URL_PATH));
																					$lastUriSegment = array_pop($uriSegments);
																					?>
																					<?php echo $lastUriSegment;?>
																				</span>
																			</td>
																			<td>
																				<span class="js-lists-values-employee-name"><?php echo date("Y-m-d",strtotime($row->product_added_date));?></span>
																			</td>
																		</tr>
																	</tbody>
																<?php }?>
															</table>
														</div>
													<?php } ?>
												<?php }?>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- container-fluid -->
		</div>
		<!-- End Page-content -->
		<?php $this->load->view('backend/include/sidebar');?>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script> 
		<script type="text/javascript" src="<?php echo base_url('js/jquery.min.js');?>"></script>
		<script type="text/javascript" src="<?php echo base_url('js/ddtf.js');?>"></script>
		<script type="text/javascript">
			$('#mytable').ddTableFilter();
		</script>
		<script type="text/javascript">
			$(document).ready(function(){
				$('.adddata').click(function(){
					var id = $(this).attr("id");
					var URL = window.location.href;
					var arr=URL.split('/');
					var storeId = arr[9];
					if(id != '')
               {
               	$.ajax({
               		url:"<?php echo base_url(); ?>backend/MyShopController/fetchBaseProductsById",
               		method:"POST",
               		data:{id:id},
               		success:function(data)
               		{
               			var obj = jQuery.parseJSON(data);
               			console.log(obj);
               			$.each(obj, function(i, item) {
               				var rows = "";
               				var db_SKU = obj[i].db_SKU;
						        	var category = obj[i].category;
						        	var sub_category = obj[i].sub_category;
						        	var brand = obj[i].brand;
						        	var product_name = obj[i].product_name;
						        	var product_type = obj[i].product_type;
						        	var product_sub_type = obj[i].product_sub_type;
						        	var product_description = obj[i].product_description;
						        	// var result = stringDivider(product_description, 40, "<br/>\n");
						        	//var productDesc = product_description.substring(0,10)
						        	var product_weight = obj[i].product_weight;
						        	var product_weight_type = obj[i].product_weight_type;
						        	var product_qty = obj[i].product_qty;
						        	var product_price = obj[i].product_price;
						        	var offer_price = obj[i].offer_price;
						        	var product_img = obj[i].product_img;

						        	rows += "<tr><td>" + storeId + "</td><td>" + db_SKU + "</td><td>" + category + "</td><td>" + sub_category + "</td><td>" + brand + "</td><td>" + product_name + "</td><td>" + product_type + "</td><td>" + product_sub_type + "</td><td>" + product_description + "</td><td>" + product_weight + "</td><td>" + product_weight_type + "</td><td>" + product_qty + "</td><td>" + product_price + "</td><td>" + offer_price + "</td><td>" + product_img + "</td></tr>";
                    			$(rows).appendTo("#displayArea");
                    			$('#QAdddata').click(function(){
                        		submitData(storeId,db_SKU,category,sub_category,brand,product_name,product_type,product_sub_type,product_description,product_weight,product_weight_type,product_qty,product_price,offer_price,product_img);
                    			});
						      });
               		}
               	});
               }
				});
				function submitData(storeId,db_SKU,category,sub_category,brand,product_name,product_type,product_sub_type,product_description,product_weight,product_weight_type,product_qty,product_price,offer_price,product_img)
				{
					var storeid = storeId;
					var sku = db_SKU;
					var cat = category;
					var subcat = sub_category;
					var brand = brand;
					var productName = product_name;
					var productType = product_type;
					var productSubType = product_sub_type;
					var productDescription = product_description;
					var productWeight = product_weight;
					var productWeightType = product_weight_type;
					var productQty = product_qty;
					var productPrice = product_price;
					var offerPrice = offer_price;
					var productImg = product_img;

					$.ajax({
						url:"<?php echo base_url(); ?>backend/MyShopController/saveBaseProductsToTemp",
						method:"POST",
						data:{storeid:storeid,sku:sku,cat:cat,subcat:subcat,brand:brand,productName:productName,productType:productType,productSubType:productSubType,productDescription:productDescription,productWeight:productWeight,productWeightType:productWeightType,productQty:productQty,productPrice:productPrice,offerPrice:offerPrice,productImg:productImg},
						success:function(data)
						{
							//location.reload(true);
							var object = jQuery.parseJSON(data);
							console.log(object);
							if(data==1){
								window.location.href= 'http://localhost:8080/public_html/asma/backend/MyShopController/viewProductsByShopId/'+storeid+'/datafrombaseDB';
							}
							else{
								window.location.href= 'http://localhost:8080/public_html/asma/backend/MyShopController/strProductConfig/'+storeid+'/datafrombaseDB';
							}
						}
					});
				}
         });
		</script>
		<script type="text/javascript">
			function PharmaCheck()
			{
				if (document.getElementById('yesPharma').checked) 
				{
					document.getElementById('ifYesPharma').style.display = 'block';
					document.getElementById('ifNoPharma').style.display = 'none';
					document.getElementById('ifYes').style.display = 'none';
					document.getElementById('ifComfortable').style.display = 'none';
					document.getElementById('ifExport').style.display = 'none';
					document.getElementById('ifMaybe').style.display = 'none';
					document.getElementById('ifMaybeYes').style.display = 'none';
					document.getElementById('ifMaybeExport').style.display = 'none';
					document.getElementById('ifHelp').style.display = 'none';
					document.getElementById('ifNo').style.display = 'none';
					$("input:radio[name=maybe]:checked")[0].checked = false;
				}
				else{	
					document.getElementById('ifYesPharma').style.display = 'none';
				}
				if (document.getElementById('noPharma').checked) 
				{
					document.getElementById('ifNoPharma').style.display = 'block';
					document.getElementById('ifMaybeExport').style.display = 'none';
					document.getElementById('ifMaybe').style.display = 'none';
					document.getElementById('ifMaybeYes').style.display = 'none';
					document.getElementById('ifHelp').style.display = 'none';
					document.getElementById('ifNo').style.display = 'none';
					$("input:radio[name=maybe]:checked")[0].checked = false;
				}
			else 
				{	document.getElementById('ifNoPharma').style.display = 'none';
		}
	}
	function SKUCheck() 
	{
		if (document.getElementById('yes').checked) 
		{
			document.getElementById('ifYes').style.display = 'block';
			document.getElementById('ifMaybeExport').style.display = 'none';
			document.getElementById('ifMaybe').style.display = 'none';
			document.getElementById('ifMaybeYes').style.display = 'none';
			document.getElementById('ifHelp').style.display = 'none';
			document.getElementById('ifNo').style.display = 'none';
			$("input:radio[name=maybe]:checked")[0].checked = false;
		}
		else 
			{	document.getElementById('ifYes').style.display = 'none';
	}
	if (document.getElementById('maybe').checked) 
	{
		document.getElementById('ifMaybe').style.display = 'block';
		document.getElementById('ifExport').style.display = 'none';
		document.getElementById('ifComfortable').style.display = 'none';
		document.getElementById('ifHelp').style.display = 'none';
		document.getElementById('ifNo').style.display = 'none';
		$("input:radio[name=yes]:checked")[0].checked = false;
		document.getElementById("ifMaybe").disabled = true;
		document.getElementById("ifComfortable").disabled = true;
		document.getElementById("ifHelp").disabled = true;
	}
	else
	{
		document.getElementById('ifMaybe').style.display = 'none';
	} 

	if (document.getElementById('no').checked) 
	{
		document.getElementById('ifNo').style.display = 'block';
		document.getElementById('ifMaybeExport').style.display = 'none';
		document.getElementById('ifExport').style.display = 'none';
		document.getElementById('ifComfortable').style.display = 'none';
		document.getElementById('ifHelp').style.display = 'none';
		document.getElementById('ifMaybeYes').style.display = 'none';
		document.getElementById("ifNo").disabled = true;
		document.getElementById("ifComfortable").disabled = true;
		document.getElementById("ifHelp").disabled = true;
		$("input:radio[name=yes]:checked")[0].checked = false;
	}
	else
	{
		document.getElementById('ifNo').style.display = 'none';
	} 
}
function yesCheck() 
{

	if (document.getElementById('comfortableCheck').checked) 
	{
		document.getElementById('ifComfortable').style.display = 'block';
		document.getElementById('ifMaybeExport').style.display = 'none';
		document.getElementById('ifMaybeYes').style.display = 'none';
		document.getElementById('ifHelp').style.display = 'none';
	}
	else 
		{	document.getElementById('ifComfortable').style.display = 'none';
}

if (document.getElementById('helpCheck').checked) 
{
	document.getElementById('ifHelp').style.display = 'block';
	document.getElementById('ifComfortable').style.display = 'none';
	document.getElementById("ifHelp").disabled = true;
}
else
{
	document.getElementById('ifHelp').style.display = 'none';
} 
}

function exportCheck()
{
	if (document.getElementById('export').click) 
	{
		document.getElementById('ifExport').style.display = 'block';
		document.getElementById('ifMaybeExport').style.display = 'none';
		var fullyByCust = 'fullyuploadedbycustomer'
		document.getElementById('fullyuploadedbycustomer').value = fullyByCust;
	}
	else 
		{	document.getElementById('ifExport').style.display = 'none';
}
}

function maybeCheck() 
{
	if (document.getElementById('maybeYesCheck').checked) 
	{
		document.getElementById('ifMaybeYes').style.display = 'block';
		document.getElementById('ifMaybeExport').style.display = 'none';
	}
	else 
		{	document.getElementById('ifMaybeYes').style.display = 'none';
}

if (document.getElementById('maybeNoCheck').checked) 
{
	document.getElementById('ifHelp').style.display = 'block';
	document.getElementById("ifHelp").disabled = true;
}
else
{
	document.getElementById('ifHelp').style.display = 'none';
} 
}

function maybeexportCheck()
{
	if (document.getElementById('maybeexport').click) 
	{
		document.getElementById('ifMaybeExport').style.display = 'block';
		document.getElementById('ifExport').style.display = 'none';
		var partialByCust = 'partiallyuploadedbycustomer'
		document.getElementById('partiallyuploadedbycustomer').value = partialByCust;
	}
	else 
		{	document.getElementById('ifMaybeExport').style.display = 'none';
}
}
</script>
<?php if($this->session->flashdata('flashSuccess')) { ?>
	<script type="text/javascript">
		window.setTimeout(function() {
			$(".successmsg").fadeTo(1000, 0).slideUp(500, function(){
				$(this).remove(); 
			});
		}, 3000);
	</script>
<?php } ?>  
<?php if($this->session->flashdata('flashError')) { ?>
	<script type="text/javascript">
		window.setTimeout(function() {
			$(".errormsg").fadeTo(900, 0).slideUp(800, function(){
				$(this).remove(); 
			});
		}, 4000);
	</script>
<?php } ?>
<style>
	.fixTableHead {
		overflow-y: auto;
		height: 510px;
	}<style>
	.fixTableHead {
		overflow-y: auto;
		height: 510px;
	}
	.NofixTableHead {
		overflow-y: auto;
		width:1000px;
	}
	table {
		border-collapse: collapse;        
		width: 100%;
	}
	th,td {
		padding: 8px 15px;
		border: 2px solid #529432;
	}
	th {
		background: #ABDD93;
	}
</style>